-- import basic functions
dofile ("extension/weather/sol/sol__config.lua")
dofile ("extension/weather/sol/sol__basics.lua")


local smoke_settings = get__Tyre_smoke_grass(true, 1)

SETTINGS = smoke_settings[1]